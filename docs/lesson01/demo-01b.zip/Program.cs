﻿// Fixed Arrays

// Dynamic Arrays (Lists)

// You can replace in both

// You can only add / remove from a list

// You can only slice an array
// from index 2 on
// up to but not including index 2

// Copy arrays with slicing
