﻿namespace demo_01a;

public static class MyFunctions
{
    // Add a function to return a 2
    public static int GetValue()
    {
        return 2;
    }

    // Add a function that changes the 2nd element
    public static void Change2ndElement(int[] array)
    {
        array[1] = 4;
    }
}