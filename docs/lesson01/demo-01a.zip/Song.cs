﻿namespace demo_01a;

public class Song
{
    // Add name & length properties
    
    // Add play method
}