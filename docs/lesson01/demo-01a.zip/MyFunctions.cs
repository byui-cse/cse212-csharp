﻿namespace demo_01a;

public static class MyFunctions
{
    // Add a function to return a 2
    

    // Add a function that changes the 2nd element
    
}