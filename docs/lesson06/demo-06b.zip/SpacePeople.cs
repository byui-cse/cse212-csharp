﻿namespace demo_06b; 

public class SpacePeople {
}