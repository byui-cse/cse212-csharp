namespace demo_06b;

public class SpacePerson {
    public string Craft { get; set; }
    public string Name { get; set; }
}