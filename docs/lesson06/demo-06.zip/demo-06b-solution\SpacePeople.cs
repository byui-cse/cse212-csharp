﻿namespace demo_06b; 

public class SpacePeople {
    public string Message { get; set; }
    public SpacePerson[] People  { get; set; }
    public int Number  { get; set; }
}