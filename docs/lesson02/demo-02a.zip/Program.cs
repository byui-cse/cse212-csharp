﻿using demo_02a;

Console.WriteLine("\n======================\nSort Demo\n======================");
Sorting.Run();