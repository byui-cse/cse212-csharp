﻿using demo_02b;

Console.WriteLine("\n======================\nGuessing Demo\n======================");
Guesser.Run();
