﻿var heap = new MinHeap();
heap.Add(4);
heap.Add(5);
heap.Add(2);
heap.Add(8);
heap.Add(1);

Console.WriteLine(heap);
heap.DisplayHeap();

Console.WriteLine("Displaying heap in order as you remove things");
Console.WriteLine("=============================================");
Console.WriteLine(heap.Remove()); // 1
Console.WriteLine(heap.Remove()); // 2
Console.WriteLine(heap.Remove()); // 4
Console.WriteLine(heap.Remove()); // 5
Console.WriteLine(heap.Remove()); // 8

try
{
    Console.WriteLine(heap.Remove()); // InvalidOperationException expected
    Console.WriteLine("InvalidOperationException expected");
}
catch (InvalidOperationException)
{
    Console.WriteLine("InvalidOperationException received as expected");
}